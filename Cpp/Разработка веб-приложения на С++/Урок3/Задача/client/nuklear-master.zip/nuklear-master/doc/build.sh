#!/bin/sh
cat ../nuklear.h|./doc > nuklear.html



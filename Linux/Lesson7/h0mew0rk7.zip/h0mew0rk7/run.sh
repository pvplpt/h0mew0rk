 #!/bin/bash
service php8.1-fpm start
/usr/sbin/nginx -g "daemon off;"
# /usr/sbin/php-fpm8.1 -F

